# Installation
npm install mongodb

# Run mongo shell example
mongo script.js

# Run node.js example
node app.js
